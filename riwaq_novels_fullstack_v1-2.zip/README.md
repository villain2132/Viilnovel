# رِواق الروايات — Full Stack
## التشغيل
1. ثبّت Node.js 20+.
2. انسخ `.env.example` إلى `.env` وغيّر AUTH_SECRET.
3. شغّل:
   npm install
   npx prisma generate
   npm run db:push
   npm run db:seed
   npm run dev
4. افتح http://localhost:3000

حساب المؤلف التجريبي:
البريد: author@riwaq.local
كلمة المرور: ChangeMe123!

غيّر كلمة المرور قبل النشر الحقيقي.

## ما تم بناؤه
تسجيل/دخول، أدوار قارئ/مؤلف، إنشاء الروايات، إضافة الفصول، قراءة الفصول، التعليقات، المكتبة، وبنية حفظ التقدم عبر جدول Progress.

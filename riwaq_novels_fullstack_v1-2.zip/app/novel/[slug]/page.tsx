import {db} from "@/lib/db";
export default async function Novel({params}:{params:Promise<{slug:string}>}){
 const {slug}=await params; const n=await db.novel.findUnique({where:{slug},include:{author:true,chapters:{orderBy:{number:"asc"}}}});
 if(!n)return <main className="wrap"><h1>الرواية غير موجودة</h1></main>;
 return <main className="wrap"><h1>{n.title}</h1><p className="muted">{n.genre} · بقلم {n.author.name}</p><p>{n.description}</p><h2>الفصول</h2>{n.chapters.map(c=><div className="chapter" key={c.id}><a href={`/reader/${c.id}`}>الفصل {c.number}: {c.title}</a><span className="muted">قراءة</span></div>)}</main>
}
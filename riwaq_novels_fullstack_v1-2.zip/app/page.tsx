import {db} from "@/lib/db";
export default async function Home(){
 const novels=await db.novel.findMany({include:{author:true,chapters:true},orderBy:{createdAt:"desc"}});
 return <><section className="hero"><div className="wrap"><h1>عالمك يبدأ من صفحة واحدة.</h1><p>منصة رِواق للروايات — اقرأ، احفظ تقدمك، علّق، وابنِ روايتك كمؤلف.</p><a className="btn" href="#novels">ابدأ القراءة</a></div></section>
 <main className="wrap" id="novels"><h2>الروايات</h2><div className="grid">{novels.map(n=><article className="card" key={n.id}><div className="cover">{n.title}</div><div className="info"><h3>{n.title}</h3><p className="muted">{n.genre} · {n.author.name} · {n.chapters.length} فصل</p><a className="btn" href={`/novel/${n.slug}`}>فتح الرواية</a></div></article>)}</div></main></>
}
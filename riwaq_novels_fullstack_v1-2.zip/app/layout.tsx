import "./globals.css";
export default function Layout({children}:{children:React.ReactNode}){
 return <><header className="top"><a className="brand" href="/"><b>رِواق</b> الروايات</a><nav className="nav"><a href="/">الرئيسية</a><a href="/library">مكتبتي</a><a href="/author">لوحة المؤلف</a><a href="/login">دخول</a></nav></header>{children}</>
}
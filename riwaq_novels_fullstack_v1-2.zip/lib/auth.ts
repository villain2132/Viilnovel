import { cookies } from "next/headers";
import { jwtVerify, SignJWT } from "jose";
const secret=new TextEncoder().encode(process.env.AUTH_SECRET || "dev-secret-change-me");
export async function setSession(user:{id:string;role:string;name:string}) {
 const token=await new SignJWT(user).setProtectedHeader({alg:"HS256"}).setExpirationTime("7d").sign(secret);
 (await cookies()).set("session",token,{httpOnly:true,sameSite:"lax",secure:process.env.NODE_ENV==="production",maxAge:604800,path:"/"});
}
export async function getSession(){
 const token=(await cookies()).get("session")?.value; if(!token)return null;
 try{return (await jwtVerify(token,secret)).payload as {id:string;role:string;name:string}}catch{return null}
}
export async function logout(){(await cookies()).delete("session");}